import os
import json
import sqlite3
from getpass import getpass
from cryptography.fernet import Fernet

class SecretsManager:
    def __init__(self, storage_type="memory",
                 file_path="secrets.json",
                 db_path="secrets.db",
                 key_file="secret.key"):
        self.storage_type = storage_type
        self.file_path = file_path
        self.db_path = db_path
        self.key_file = key_file
        self._init_key()

        # In-memory store
        self.memory_store = {}

        if self.storage_type == "file":
            if os.path.exists(self.file_path):
                self._load_file()

        if self.storage_type == "db":
            self._init_db()

    def _init_key(self):
        """Generate or load encryption key."""
        if not os.path.exists(self.key_file):
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
        with open(self.key_file, "rb") as f:
            self.fernet = Fernet(f.read())

    # ---------- FILE STORAGE ----------
    def _load_file(self):
        """Load encrypted data from JSON file manually."""
        with open(self.file_path, "r") as f:
            self.memory_store = json.loads(f.read())

    def _save_file(self):
        """Save encrypted data to JSON file manually."""
        with open(self.file_path, "w") as f:
            json.dump(self.memory_store, f, indent=4)

    # ---------- DATABASE STORAGE ----------
    def _init_db(self):
        """Initialize SQLite database manually."""
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS secrets (
                service TEXT PRIMARY KEY,
                encrypted_key TEXT
            )
        """)
        self.conn.commit()

    def _save_db(self, service, encrypted):
        """Insert or replace secret in DB."""
        self.cursor.execute("""
            INSERT OR REPLACE INTO secrets (service, encrypted_key)
            VALUES (?, ?)
        """, (service, encrypted))
        self.conn.commit()

    def _load_db(self, service):
        """Load secret from DB."""
        self.cursor.execute("""
            SELECT encrypted_key FROM secrets WHERE service = ?
        """, (service,))
        row = self.cursor.fetchone()
        return row[0] if row else None

    # ---------- MAIN API ----------
    def store_secret(self, service, api_key):
        """Encrypt and store API key."""
        encrypted = self.fernet.encrypt(api_key.encode()).decode()

        if self.storage_type == "memory":
            self.memory_store[service] = encrypted

        elif self.storage_type == "file":
            self.memory_store[service] = encrypted
            self._save_file()

        elif self.storage_type == "db":
            self._save_db(service, encrypted)

        print(f"[+] Secret for '{service}' stored securely.")

    def retrieve_secret(self, service):
        """Decrypt and retrieve API key."""
        if self.storage_type == "memory":
            encrypted = self.memory_store.get(service)

        elif self.storage_type == "file":
            encrypted = self.memory_store.get(service)

        elif self.storage_type == "db":
            encrypted = self._load_db(service)

        else:
            encrypted = None

        if not encrypted:
            print(f"[!] No secret found for service: {service}")
            return None

        decrypted = self.fernet.decrypt(encrypted.encode()).decode()
        return decrypted

    def close(self):
        if self.storage_type == "db":
            self.conn.close()

def main():
    print("Choose storage type:\n1. In-memory\n2. File\n3. SQLite DB")
    choice = input("Enter choice (1/2/3): ")
    storage_type = "memory" if choice == "1" else "file" if choice == "2" else "db"

    manager = SecretsManager(storage_type=storage_type)

    while True:
        print("\nOptions:\n1. Store Secret\n2. Retrieve Secret\n3. Exit")
        action = input("Enter choice: ")

        if action == "1":
            service = input("Enter Service Name: ")
            api_key = getpass("Enter API Key (hidden): ")
            manager.store_secret(service, api_key)

        elif action == "2":
            service = input("Enter Service Name: ")
            key = manager.retrieve_secret(service)
            if key:
                print(f"[+] API Key for {service}: {key}")

        elif action == "3":
            print("Exiting...")
            manager.close()
            break

        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
