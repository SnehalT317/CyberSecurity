#!/usr/bin/env python3
import sys
import whois
import tldextract
import time
import subprocess
import shutil
import idna

# --- Configuration ---
RETRY_COUNT = 3
RETRY_BACKOFF = 2  # seconds
RATE_LIMIT = 0.5   # seconds between requests

def normalize_domain(domain):
    """Normalize to base domain, e.g., www.google.com -> google.com"""
    ext = tldextract.extract(domain)
    if not ext.suffix:
        return domain
    return f"{ext.domain}.{ext.suffix}"

def to_punycode(domain):
    """Convert IDN to ASCII/punycode"""
    try:
        return idna.encode(domain).decode()
    except idna.IDNAError:
        return domain

def system_whois(domain):
    """Fallback to system whois if python-whois fails"""
    if shutil.which("whois"):
        try:
            result = subprocess.run(
                ["whois", domain],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10
            )
            return result.stdout.strip() or "N/A"
        except Exception as e:
            return f"system whois error: {e}"
    return "system whois not installed"

def lookup_domain(domain):
    domain = normalize_domain(domain)
    domain = to_punycode(domain)
    for attempt in range(RETRY_COUNT):
        try:
            w = whois.whois(domain)
            registrar = w.registrar if w and w.registrar else "N/A"
            return domain, registrar
        except Exception as e:
            if attempt < RETRY_COUNT - 1:
                time.sleep(RETRY_BACKOFF * (attempt + 1))
            else:
                # fallback to system whois
                fallback = system_whois(domain)
                return domain, f"Fallback: {fallback[:80]}..."

def main():
    domains = []
    file_path = None

    # --- parse CLI args manually ---
    args = sys.argv[1:]
    if not args:
        user_input = input("Enter space-separated domains (or leave blank to use a file): ").strip()
        if user_input:
            domains = user_input.split()
        else:
            file_path = input("Enter path to a file containing domains: ").strip()
    else:
        if args[0] == "--file":
            if len(args) > 1:
                file_path = args[1]
            else:
                print("Error: --file flag provided but no file path given.")
                sys.exit(1)
        else:
            domains = args

    # --- load from file if needed ---
    if file_path and not domains:
        try:
            with open(file_path) as f:
                for line in f:
                    for part in line.split():
                        domains.append(part.strip())
        except FileNotFoundError:
            print(f"Error: file not found: {file_path}")
            sys.exit(1)

    if not domains:
        print("No domains provided. Exiting.")
        sys.exit(1)

    # --- run lookups ---
    results = []
    for d in domains:
        domain, registrar = lookup_domain(d)
        print(f"{domain} → {registrar}")
        results.append((domain, registrar))
        time.sleep(RATE_LIMIT)

    # --- optionally save CSV ---
    try:
        import csv
        with open("whois_results.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Domain", "Registrar"])
            writer.writerows(results)
    except Exception:
        pass

if __name__ == "__main__":
    main()

